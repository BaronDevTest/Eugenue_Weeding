# Wedding QR Gallery

Aplicatie Node.js pentru nunta: invitatii scaneaza un QR code, incarca poze (si video-uri) de pe telefon, fisierele se salveaza automat in Google Drive si toata lumea poate vedea galeria in timp real.

## Functionalitati

- **Pagina publica** cu numele mirilor, mesaj de welcome si butoane mari pentru upload/galerie.
- **Upload prietenos cu telefonul** — selecteaza din galerie sau scoate direct cu camera, multiple fisiere o data.
- **Galerie live** cu toate pozele incarcate (cu nume invitat si mesaj optional).
- **Pagina admin** protejata cu parola, unde poti:
  - vedea statistici si starea conexiunii cu Drive,
  - genera si descarca QR code-ul (pentru upload sau pentru galerie),
  - modera pozele (sterge fisierele nedorite),
  - schimba numele mirilor, mesajul de welcome, folder-ul Drive si parola admin.

Stack: Express + EJS + Google Drive API (Service Account). Fara build step, fara native modules — compatibil 100% cu hosting cPanel (Phusion Passenger).

---

## 1. Setup Google Drive (Service Account)

Service Account-ul este "robotul" care urca pozele in Drive-ul tau. Invitatii nu se logheaza niciodata cu Google.

### 1a. Creeaza proiectul si activeaza API-ul

1. Intra in [Google Cloud Console](https://console.cloud.google.com/) cu contul tau Google.
2. Creeaza un proiect nou (ex: `nunta-pavel`).
3. In meniul stang: **APIs & Services → Library** → cauta `Google Drive API` → **Enable**.

### 1b. Creeaza Service Account-ul

1. **IAM & Admin → Service Accounts → Create Service Account**.
2. Nume: `wedding-uploader` (orice nume).
3. La pasul cu permisiunile (Role) — lasa gol, apasa Continue.
4. La pasul final, apasa Done.

### 1c. Genereaza cheia JSON

1. In lista de Service Accounts, click pe cel nou creat.
2. Tab-ul **Keys → Add Key → Create new key → JSON**.
3. Se descarca un fisier `xxx.json`. **Redenumeste-l in `service-account.json`** si pune-l in radacina proiectului (langa `app.js`).
4. **Nu il commiteaza in git!** Este deja in `.gitignore`.

Deschide fisierul si copiaza valoarea `client_email` — arata cam asa: `wedding-uploader@nunta-pavel.iam.gserviceaccount.com`.

### 1d. Creeaza folder-ul Drive si partajeaza-l

1. Intra in [Google Drive](https://drive.google.com/) cu contul tau personal.
2. Creeaza un folder nou (ex: `Poze nunta - de la invitati`).
3. Click dreapta pe folder → **Share** → adauga email-ul service account-ului (`wedding-uploader@...`) cu drepturi de **Editor**.
4. Deschide folder-ul si copiaza ID-ul din URL:
   ```
   https://drive.google.com/drive/folders/1aBcD3FgHiJkLmNoPqRsTuVwXyZ
                                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                          asta e ID-ul folderului
   ```

---

## 2. Setup local (development)

```bash
# Cloneaza / copiaza proiectul, apoi:
cp .env.example .env
# Editeaza .env si pune valorile reale (PUBLIC_URL, SESSION_SECRET, GOOGLE_DRIVE_FOLDER_ID, ADMIN_INITIAL_PASSWORD)

# Pune service-account.json in radacina proiectului

npm install
npm start
```

Deschide [http://localhost:3000](http://localhost:3000).

Pagina admin: [http://localhost:3000/admin](http://localhost:3000/admin) — login cu parola din `ADMIN_INITIAL_PASSWORD`. Schimba parola din `/admin/settings` dupa primul login.

---

## 3. Deploy pe cPanel

cPanel suporta Node.js apps prin Phusion Passenger. Pasi:

### 3a. Upload fisiere

1. In cPanel → **File Manager** sau prin FTP — copiaza intregul proiect (mai putin `node_modules/` si `.env`) intr-un folder (ex: `nunta_app/` in afara `public_html`).
2. Pune `service-account.json` in acelasi folder.
3. Creeaza fisierul `.env` direct pe server (din File Manager) si completeaza:
   - `PUBLIC_URL=https://nunta.exemplu.ro`
   - `SESSION_SECRET=...` (random, lung)
   - `GOOGLE_DRIVE_FOLDER_ID=...`
   - `ADMIN_INITIAL_PASSWORD=...`

### 3b. Configureaza aplicatia Node.js in cPanel

1. In cPanel → cauta **Setup Node.js App** (sau Node.js Selector).
2. **Create Application**:
   - **Node.js version**: 18.x sau mai nou.
   - **Application mode**: Production.
   - **Application root**: `nunta_app` (folderul unde ai pus fisierele).
   - **Application URL**: subdomeniu/path (ex: `nunta.exemplu.ro` sau `exemplu.ro/nunta`).
   - **Application startup file**: `app.js`.
3. Save.
4. In ecranul aplicatiei → **Run NPM Install** (instaleaza dependentele).
5. **Restart** aplicatia.

### 3c. Test

1. Deschide URL-ul aplicatiei in browser.
2. Mergi la `/admin` si logheaza-te cu parola initiala.
3. Verifica in **Dashboard** ca `Drive conectat la folderul ...` apare verde. Daca apare rosu, ai uitat sa partajezi folderul Drive cu service account-ul.
4. Schimba parola din **Setari**.
5. Genereaza QR-ul, printeaza-l, lipeste-l pe invitatii / mese.

---

## 4. Variabile de mediu

| Variabila | Obligatorie | Descriere |
|-----------|-------------|-----------|
| `PORT` | nu (cPanel o seteaza automat) | Portul serverului local |
| `PUBLIC_URL` | da pe productie | URL public, folosit la generarea QR-ului |
| `SESSION_SECRET` | da | Secret random pentru sesiunile admin |
| `GOOGLE_SERVICE_ACCOUNT_FILE` | nu | Path catre fisierul JSON. Default `./service-account.json` |
| `GOOGLE_SERVICE_ACCOUNT_JSON` | alternativa | JSON-ul cheii ca string (in loc de fisier) |
| `GOOGLE_DRIVE_FOLDER_ID` | da | ID-ul folder-ului Drive |
| `ADMIN_INITIAL_PASSWORD` | da la primul start | Parola admin initiala (poti schimba din UI) |
| `NODE_ENV` | recomandat | `production` pe live (activeaza secure cookies) |

---

## 5. Structura proiectului

```
.
├── app.js                       # entry point Express + Passenger
├── package.json
├── .env.example
├── service-account.json         # NU committed; cheia Google
├── config/
│   └── settings.json            # generat la primul start (NU committed)
├── public/css/style.css         # CSS
├── views/                       # template-uri EJS
│   ├── index.ejs, upload.ejs, gallery.ejs, ...
│   ├── admin/login.ejs, dashboard.ejs, qr.ejs, photos.ejs, settings.ejs
│   └── partials/
└── src/
    ├── routes/public.js
    ├── routes/admin.js
    ├── services/drive.js        # Google Drive API
    ├── services/settings.js     # config persistent
    └── middleware/auth.js
```

---

## 6. Probleme frecvente

**"Nu gasesc fisierul service-account la ..."**
Pune fisierul `service-account.json` in radacina proiectului sau seteaza `GOOGLE_SERVICE_ACCOUNT_FILE` in `.env`.

**"Folder Drive nu este configurat"**
Intra in `/admin/settings` si completeaza ID-ul folderului, sau seteaza `GOOGLE_DRIVE_FOLDER_ID` in `.env`.

**Drive apare rosu in dashboard cu "File not found"**
Ai uitat sa partajezi folderul Drive cu email-ul service account-ului. Vezi pasul 1d.

**Pozele nu se vad in galerie**
Aplicatia seteaza permisiuni publice pe fiecare fisier la upload (Anyone with the link can view). Daca ai politici GSuite care blocheaza public sharing, foloseste un cont Google personal pentru folder, nu unul de Workspace cu restrictii.

**Upload-ul esueaza pentru fisiere mari**
Mareste `maxUploadMb` in `/admin/settings`. Pe cPanel verifica si `client_max_body_size` daca este expus.

**Vreau sa folosesc subdomeniu HTTPS dar Passenger imi da redirect issue**
Adauga `app.set('trust proxy', 1)` este deja in `app.js`. Pe cPanel asigura-te ca aplicatia este accesata prin HTTPS de la inceput.

---

## 7. Licenta

Pentru uz personal la nunta ta. Modifica liber.
